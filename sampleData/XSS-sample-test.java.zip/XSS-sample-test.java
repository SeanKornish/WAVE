import net.sourceforge.jwebunit.junit.WebTester;
import org.junit.Before;
import org.junit.Test;

public class SampleWebTestXSS {
    private WebTester tester;

        @Before
        public void prepare() {
            tester = new WebTester();
            tester.setBaseUrl("http://localhost:8080/testing/");
        }

        @Test
        public void testXSS() {
            tester.beginAt("reflected-xss.html");
            tester.setTextField("name", "<script id=\"xss\" >console.log(\"XSS\")</script>");
            tester.clickButton("submit");
            tester.assertElementPresent("xss");
        }
}
